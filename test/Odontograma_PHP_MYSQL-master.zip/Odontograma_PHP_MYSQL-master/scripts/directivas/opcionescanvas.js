app.directive('opcionescanvas',function(){
    return {restrict:'E',
            scope:{},
            templateUrl:'opciones_canvas.html'}
});
