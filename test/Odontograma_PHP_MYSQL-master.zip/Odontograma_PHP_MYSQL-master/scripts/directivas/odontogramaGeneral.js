app.directive('odontogramageneral',function(){
    return{
        restrict:'E',
        scope:{},
        templateUrl:'odontograma.html'
    };
    
});
